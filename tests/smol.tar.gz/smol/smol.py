#!/usr/bin/env python3

import numpy as np

x0 = 1.5
D = 0.5
b = 0.1
c = 1.0
dt = 0.3543
s = np.sqrt(2*D*dt)
m = x0-D*b*c*dt
n = 1000000

a = np.random.normal(m, s, size=(n, 1)).flatten()
print('\n'.join(map(str, a)))
